import {
  Host,
  login,
  register
  ,imgUpload
} from "./constants.js";
function handleSuccess(result) {
}

function handleError(error) {
  var errorCode = error.statusCode;
  if (errorCode == 401) {
    loginTo();
  } else if (errorCode == 500) {
      if (wx.getStorageSync("token") == "") {
          loginTo();
      } else {
          wx.showToast({
              title: error.data.message + "",
              icon: "none",
              duration: 3000
          });
      }
  } else if(errorCode == 400) {
    wx.showToast({
        title: error.data.message + "",
        icon: "none",
        duration: 1000
    });
  } else {
      wx.showLoading({
          title: error.data.message
      });
      setTimeout(function () {
        wx.hideLoading()
      }, 2000)
  }
}

function header() {
  var head = {
      Authorization: wx.getStorageSync("token")
  };
  return head;
}

function wxPromisify(fn) {
  return function (obj = {}) {
      return new Promise((resolve, reject) => {
          obj.success = function (result) {
              if (result.data.success) {
                  handleSuccess(result);
                  resolve(result.data);
              } else {
                  resolve(result.data);
                  handleError(result);
              }
          };
          obj.fail = function (error) {
              handleError(error);
              reject(error);
          };
          fn(obj);
      });
  };
}

//无论promise对象最后状态如何都会执行
Promise.prototype.finally = function (callback) {
  let P = this.constructor;
  return this.then(
      value => P.resolve(callback()).then(() => value),
      reason =>
          P.resolve(callback()).then(() => {
              throw reason;
          })
  );
};
function checklogin() {
  wx.checkSession({
    success () {
    },
    fail () {
      loginTo();
    }
  })
}
function loginTo() {
  wx.navigateTo({
    url: '/pages/login/index',
  })
}
function Post(url, paramObj, ischeck = false) {
  var getRequest = wxPromisify(wx.request);
  if (!ischeck) {
      checklogin()
  }
  return getRequest({
      url: Host + url,
      data: paramObj,
      header: header(),
      method: "POST"
  });
}

function Get(url,paramObj, ischeck = false) {
  var getRequest = wxPromisify(wx.request);
  if (!ischeck) {
      checklogin()
  }
  console.log("resquet urls--"+Host + url)
  return getRequest({
      url: Host + url,
      data: paramObj,
      header: header(),
      method: "GET"
  });
}

function Delete(url, ischeck = false) {
  var getRequest = wxPromisify(wx.request);
  if (!ischeck) {
    checklogin()
  }
  return getRequest({
      url: Host + url,
      header: header(),
      method: "DELETE"
  });
}

function Put(url, paramObj) {
  var getRequest = wxPromisify(wx.request);
  return getRequest({
      url: Host + url,
      data: paramObj,
      header: header(),
      method: "PUT"
  });
}

function FileUploadInternal(ops) {
    wx.uploadFile({
        filePath: ops.file,
        name: 'file',
        header: header(),
        url:  Host + imgUpload,
        success:function(params) {
          if(params.statusCode == 200){
            ops.success(params);
          } else {
              handleError(params);
          }
        },
    })
}

export const httpService = {
  get: Get,
  post: Post,
  delete: Delete,
  put: Put,
  fileUploadInternal: FileUploadInternal
};

