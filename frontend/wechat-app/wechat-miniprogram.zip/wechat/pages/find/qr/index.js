
import {
  httpService
} from "../../../providers/httpService";
import {
  qrCreate,
  imgPreview,
  currentUserCache,
  currentUser
} from "../../../providers/constants";
const app = getApp();
Page({
  data:{
    qrUrl:"",
    userInfo:{}
  },
  onLoad:function() {
    this.createQr();
    this.initUser();
  },
  createQr:function() {
    httpService.get(qrCreate).then(res =>{
      if (res.success) {
       var qrUrl = res.data.qrUrl;
       this.setData({
         qrUrl:qrUrl
       });
      }
    })
  },
  initUser:function() {
    var userInfo;
    var that = this;
    wx.getStorage({
      key: 'currentUserCache',
      success(res) {
        that.setData({
          userInfo:res.data
        })
      }
    })
    if (!userInfo) {
      httpService.get(currentUser).then(res => {
        userInfo = res.data;
        if (res.success) {
          that.setAndCacheUser(userInfo);
        }
      });
    }
  },
  /**
   * 设置用户信息&缓存
   * @param {*} user 
   */
  setAndCacheUser:function(user) {
    wx.setStorage({
      data: user,
      key: 'currentUserCache'
    });
    this.setData({
      userInfo: user,
      hasUserInfo: true
    })
  }
})