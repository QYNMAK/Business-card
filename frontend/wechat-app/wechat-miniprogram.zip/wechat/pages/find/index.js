import {
  customer,
  imgPreview,
  cacheHistory
} from "../../providers/constants";
const app = getApp()

Page({
  /** 
   * 页面的初始数据 
   */
  data: {
    isActive: null,
    listMain: [],
    listTitles: [],
    fixedTitle: null,
    toView: 'inToView0',
    oHeight: [],
    scroolHeight: 0,
    inputShowed: false,
    searchActive: false,
    imgPreview: imgPreview,
    cacheInterval: null,
    searchKey: ''
  },

  onLoad: function (options) {
    var that = this;
    var filter = that.data.searchKey;
    that.loadCache(filter);
    var cacheInterval = setInterval(function () {
      var filter = that.data.searchKey;
      that.loadCache(filter);
    }, 3000);
    this.setData({
      cacheInterval: cacheInterval
    })
  },
  onUnload: function () {
    clearInterval(this.data.cacheInterval)
  },
  /**
   * 加载浏览历史
   */
  loadCache(filter) {
    var that = this;
    var filterUser = [];
    wx.getStorage({
      key: cacheHistory,
      success(res) {

        res.data.forEach(user => {
          if (user.name.length > 2) {
            user['showName'] = user.name.substring(user.name.length - 2, user.name.length);
          } else {
            user['showName'] = user.name;
          }
          filterUser.push(user);
        });
        if (filter) {
          filterUser.forEach(function (item, index, arr) {
            if (item.name != filter && item.phone != filter) {
              arr.splice(index, 1);
            } else {
              console.log('filter ss', item)
            }
          });
        }
        that.setData({
          listMain: filterUser
        })
      },
      fail(res) {}
    })
  },
  /**
   * 搜索
   * 
   */
  searchCache: function (e) {
    this.setData({
      searchKey: e.detail.value
    })
    this.loadCache(e.detail.value);
  },
  // 使文本框进入可编辑状态
  showInput: function (e) {
    this.setData({
      inputShowed: true
    });

  },
  // 取消搜索
  hideInput: function () {
    this.setData({
      inputShowed: false
    });
    this.setData({
      searchKey: ""
    })
    this.loadCache();
  },
  addUser: function () {
    wx.navigateTo({
      url: '../../pages/find/find-add/index',
    })
  },
  /**
   * 详情
   */
  userDetail: function (e) {
    wx.navigateTo({
      url: '../index/detail/index',
      success: function (res) {
        res.eventChannel.emit('customerDetail', {
          uid: e.currentTarget.dataset.id
        })
      }
    })
  },
  /**
   * 我的二维码
   */
  qr: function () {
    wx.navigateTo({
      url: 'qr/index'
    })
  },
  qrScan: function () {
    // 只允许从相机扫码
    wx.scanCode({
      onlyFromCamera: true,
      success(res) {
        var uid = res.result;
        wx.navigateTo({
          url: './qr-scan/index',
          success: function(res) {
            res.eventChannel.emit('scan-add', {uid:uid})
          }
        })
      }
    })
  }

})