const app = getApp()
import {
  httpService
} from "../../providers/httpService";
import {
  loginOut,
  token,
  cacheHistory,
  currentUserCache,
  currentUser
} from "../../providers/constants";
Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../user/user'
    })
  },
  onLoad: function () {
    var userInfo = wx.getStorageSync('currentUserCache');
    var that = this;
    if (!userInfo) {
      httpService.get(currentUser).then(res => {
        userInfo = res.data;
        if (res.success) {
          that.setAndCacheUser(userInfo);
        }
      });
    };
    this.setData({
      userInfo:userInfo
    })
  },
  /**
   * 获取用户信息
   * @param {*} e 
   */
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
   /**
   * 设置用户信息&缓存
   * @param {*} user 
   */
  setAndCacheUser:function(user) {
    wx.setStorageSync({
      data: user,
      key: 'currentUserCache'
    });
    this.setData({
      userInfo: user,
      hasUserInfo: true
    })
  }
  ,
  /**
   * 退出登陆
   */
  loginOut: function () {
    // 服务端清除
    httpService.get(loginOut);
    // 清空本地缓存
    wx.removeStorage({
      key: token
    })
    // 跳转到登陆
    wx.navigateTo({
      url: '../login/index',
    })
  },
  /**
   * 清除缓存
   */
  clearCahce: function () {
    wx.removeStorage({
      key: cacheHistory,
    })
  },
  /**
   * 修改个人信息
   */
  setting:function(){
    var user = this.data.userInfo;
    wx.navigateTo({
      url: './setting/setting',
      success: function(res) {
        res.eventChannel.emit('setting', {user:user})
      }
    })
  }
})