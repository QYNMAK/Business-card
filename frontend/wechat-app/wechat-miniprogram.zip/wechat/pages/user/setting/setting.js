import {
  httpService
} from "../../../providers/httpService";
import {
  customerAdd,
  currentUser,
  userUpdate,
  userQuery,
  imgPreview
} from "../../../providers/constants";
import WxValidate from "../../common/WxValidate";
import TelValidate from "../../common/WxValidate";
Page({
  data: {
    user: {
      phoneNums: [""],
      region: []
    },
    uploadLimit: 10,
    regionPickerActive: false,
    regionSelected: '请选择所在区域',
    previewImgUrl: imgPreview
  },
  /**
   * 所在区域选择
   * 
   * @param {区域对象} e 
   */
  bindRegionChange: function (e) {
    var selectedRegion = e.detail.value[0] + "-" + e.detail.value[1] + "-" + e.detail.value[2];
    this.setData({
      region: e.detail.value,
      regionPickerActive: true,
      regionSelected: selectedRegion
    })
  },
  /**
   * 选择手机图片或拍照
   * 
   * @param {*} e 
   */
  imgUpload: function (e) {
    var user = this.data.user;
    var canUpload = this.data.user.imgs.length < 10;
    if (!canUpload) {
      wx.showToast({
        title: '最多支持10张图片',
        icon: 'none',
        duration: 1500
      })
      return false;
    }
    var canUploadCount = this.data.uploadLimit - this.data.user.imgs.length;
    let that = this;
    wx.chooseImage({
      count: canUploadCount,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        const tempFilePaths = res.tempFilePaths
        let imgs = that.data.user.imgs;
        tempFilePaths.filter(file => {
          httpService.fileUploadInternal({
            file: file,
            success: function (params) {
              imgs.push(JSON.parse(params.data).data);
              user['imgs'] = imgs
              that.setData({
                user: user
              })
            }
          });
        })
      }
    })
  },
  /**
   * 图片移除
   * 
   * @param {图片对象} e 
   */
  uploadRemove: function (e) {
    var user = this.data.user;
    var imgs = user.imgs;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    this.setData({
      user: user
    });
  },
  /**
   * 新增手机号
   */
  addPhoneNum: function (e) {
    var phoneNums = this.data.user.phoneNums;
    if (phoneNums.length >= 10) {
      wx.showModal({
        content: "最多只能填写10个手机号",
        showCancel: false,
      })
    }
    var telObj = e.currentTarget.dataset;
    var tested = this.TelValidate.checkForm(telObj);

    if (!tested) {

      const error = this.TelValidate.errorList[0]
      wx.showModal({
        content: error.msg,
        showCancel: false,
      })
      return false
    }

    phoneNums.push("");
    var user = this.data.user;
    user['phoneNums'] = phoneNums;
    this.setData({
      user: user
    })
  },
  /**
   * 删除手机号
   * 
   * @param {*} e 
   */
  removePhoneNum: function (e) {
    var index = e.currentTarget.dataset.index;
    var user = this.data.user;
    var phoneNums = user.phoneNums;
    phoneNums.splice(index, 1)
    this.setData({
      user: user
    })
  },
  /**
   * 双向绑定电话号码
   * @param {*} e 
   */
  bindPhoneNum: function (e) {
    var index = e.currentTarget.dataset.index;
    var tel = e.detail.value;
    var phoneNums = this.data.user.phoneNums;
    phoneNums[index] = tel;
    var user = this.data.user;
    user['phoneNums'] = phoneNums;
    var userPhoneNums = ["user.phoneNums"];
    this.setData({
      userPhoneNums: phoneNums
    })
  },
  /**
   * 图片预览
   * 
   * @param {图片对象} e 
   */
  imgPreview: function (e) {
    var imgIndex = e.currentTarget.dataset.index;
    var imgs = this.data.imgs;
    var preImgs = new Array(4);
    for (let index = 0; index < imgs.length; index++) {
      preImgs[index] = this.data.previewImgUrl + imgs[index];
    }

    wx.previewImage({
      current: preImgs[imgIndex],
      urls: preImgs
    })
  },
  /**
   * 提交表单
   * 
   * @param {表单对象} e 
   * @param {用户信息} currentUser 
   */
  submitRel: function (e, currentUser) {
    this.cacheUser(currentUser);
    httpService.post(userUpdate, currentUser, true).then(res => {
      if (res.success) {
        wx.hideToast();
        wx.reLaunch({
          url: '../../../pages/user/user',
        })
      }
      return false;
    });

  },
  /**
   * 表单提交
   * 
   * @param {表单对象} e 
   */
  formSubmit: function (e) {

    const params = e.detail.value
    // 传入表单数据，调用验证方法
    if (!this.WxValidate.checkForm(params)) {

      const error = this.WxValidate.errorList[0]
      wx.showModal({
        content: error.msg,
        showCancel: false,
      })
      return false
    }

    wx.showToast({
      title: '保存中···',
      icon: 'loading',
      duration: 100000
    })

    params['phoneNums'] = this.data.user.phoneNums;
    params['headPic'] = this.data.user.headPic;

    this.submitRel(e, params);
  },
  /**
   * 初始化验证
   */
  initValidate() {
    let rules = {
      username: {
        required: true,
        maxlength: 20
      }
    }

    let message = {
      username: {
        required: '请输入姓名',
        maxlength: '名字不能超过10个字'
      }
    }
    //实例化当前的验证规则和提示消息
    this.WxValidate = new WxValidate(rules, message);

  },
  /**
   * 初始化验证
   */
  telValidate() {
    let rules = {
      tel: {
        required: true,
        number: true,
        tel: true
      }
    }

    let message = {

      tel: {
        required: '请输入手机号',
        tel: '请输入正确的手机号'
      }
    }
    //实例化当前的验证规则和提示消息
    this.TelValidate = new WxValidate(rules, message);

  },
  /**
   * 事件处理
   */
  doEvent: function () {
    const eventChannel = this.getOpenerEventChannel();
    var that = this;
    eventChannel.on('setting', function (data) {
      httpService.get(userQuery + '/' + data.user.id).then(res => {

        var userInfo = res.data;
        userInfo['phoneNums'] = [""];
        if (userInfo.phone && userInfo.phone.length > 0) {
          userInfo['phoneNums'] = userInfo.phone.split(",");
        }
        userInfo['region'] = [];
        if (userInfo.province) {
          userInfo['region'].push(userInfo.province);
          userInfo['region'].push(userInfo.city);
          userInfo['region'].push(userInfo.county);
        }

        if (userInfo.region.length >= 3) {
          that.setData({
            regionSelected: userInfo.region.join('-')
          })
        }
        that.cacheUser(userInfo);
        that.setData({
          user: userInfo
        })
      })
    })
  },
  /**
   * 更换头像
   */
  changeAvatar: function () {

    var that = this;
    this.uploadImg(that.changeAvatarAndSet, 1);
  },
  /**
   * 更改用户头像
   * @param {*} imgId 
   */
  changeAvatarAndSet: function (imgId) {
    this.setData({
      ['user.headPic']: this.data.previewImgUrl + imgId
    })
  },
  /**
   * 图片上传
   * @param {*} resolve 
   */
  uploadImg(resolve, canUploadCount) {
    wx.chooseImage({
      count: canUploadCount,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        const tempFilePaths = res.tempFilePaths
        tempFilePaths.filter(file => {
          httpService.fileUploadInternal({
            file: file,
            success: function (params) {
              resolve(JSON.parse(params.data).data);
            }
          });
        })
      }
    })
  },
  /**
   * 设置用户信息缓存
   * @param {*} user 
   */
  cacheUser: function (user) {
    wx.removeStorageSync('currentUserCache')
    wx.setStorageSync({
      data: user,
      key: 'currentUserCache'
    });
    this.setData({
      user: user,
    })
  },
  onLoad: function () {
    this.initValidate();
    this.telValidate();
    this.doEvent();
  }
})