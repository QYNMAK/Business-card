//index.js
//获取应用实例
import {
  httpService
} from "../../providers/httpService";
import {
  customerPage,
  imgUpload
} from "../../providers/constants";
const app = getApp()

Page({
  /** 
   * 页面的初始数据 
   */
  data: {
    isActive: null,
    listMain: [],
    listTitles: [],
    sortAscImg: '../../images/sort_asc.png',
    sortDescImg: '../../images/sort_desc.png',
    nameSortImg: '../../images/sort_asc.png',
    ageSortImg: '../../images/sort_asc.png',
    nameSort: 'asc',
    ageSort: 'asc',
    fixedTitle: null,
    toView: 'inToView0',
    keywords: '',
    oHeight: [],
    scroolHeight: 0,
    inputShowed: false, 
    sortParams: {
      age: '',
      name: ''
    },
    queryParams: {},
    searchActive: false,
    animationSearch:'',
    searchOptions:true
  },
  /**
   * 排序 排序选项 age,name
   * @param {*} e 
   */
  changeSort: function (e) {
    var sortid = e.currentTarget.id;
    var sortImg = sortid + 'Img';
    var sortParms = this.data.sortParams;
    var sortValue = e.currentTarget.dataset.sort;
    sortParms[sortid.replace("Sort", "")] = sortValue;

    if (sortValue == 'asc') {
      this.setData({
        [sortImg]: '../../images/sort_desc.png',
        [sortid]: 'desc'
      })
    } else if (sortValue == 'desc') {
      this.setData({
        [sortImg]: '../../images/sort_asc.png',
        [sortid]: 'asc'
      })
    }
    var queryParams = {
      ascs: [],
      descs: []
    };
    if (sortParms.age != '') {
      queryParams[this.data.ageSort + "s"].push('age');
    }
    if (sortParms.name != '') {
      queryParams[this.data.nameSort + "s"].push('name');
    }
    queryParams.ascs = queryParams.ascs.join(',');
    queryParams.descs = queryParams.descs.join(',');
    this.setData({
      queryParams: queryParams
    })
    queryParams['keywords'] = this.data.keywords;
    this.getUsers(queryParams);
  },
  // 页面滑动时触发
  onPageScroll: function (e) {
    var searchActive =false;
    if (e.detail.scrollTop > 0) {
      searchActive = true;
    }
    
    this.setData({
      searchActive: searchActive
    });
    
   
  },
  // 处理数据格式，及获取分组高度
  getUsers: function (params = {}) {
    var that = this;
    var users = [];
    httpService.get(customerPage, params).then(res => {
      
      if (res.success) {
        users = res.data.records;
        users.forEach(user => {
          if (user.name.length > 2) {
            user['showName'] = user.name.substring(user.name.length - 2, user.name.length);
          } else {
            user['showName'] = user.name;
          }
        });
        that.setData({
          listMain: res.data.records
        })
      }
    })
  },

  onLoad: function (options) {
    var that = this;
    that.getUsers();
   
  },
  onShow: function () {
  },
  // 使文本框进入可编辑状态
  showInput: function () {
    this.setData({
      inputShowed: true //设置文本框可以输入内容
    });
  },
  // 取消搜索
  hideInput: function () {

    this.setData({
      inputShowed: false
    });

    if (this.data.keywords == '') {
      return;
    }
    this.setData({
      keywords: ''
    });
    console.log("keywords", this.data.keywords)
    this.getUsers();
  },
  updateValue(e) {
    let name = e.currentTarget.dataset.name;
    let nameMap = {}
    nameMap[name] = e.detail && e.detail.value
    var queryParams = this.data.queryParams;
    queryParams[name] = e.detail && e.detail.value;
    this.setData(queryParams);
    // this.setData(nameMap);
  },
  /**
   * 搜索
   * @param {*} e 
   */
  searchSubmit: function (e) {
    if (!e.detail.value) {
      this.setData({
        inputShowed: false
      });
      return;
    }
    this.setData({
      keywords: e.detail.value
    });

    var params = this.data.queryParams;
    params['keywords'] = e.detail.value;
    this.getUsers(params);

  },
  onReady: function () {
    this.animation = wx.createAnimation()
  },
  /**
   * 侧栏搜索
   */
  multiparSearch: function(){
    this.setData({
      searchOptions:false
    })
    this.animation.translate(-50, -1).step()
    this.setData({animation: this.animation.export()})
  },
  /**
   * 侧栏提交搜索
   * @param {*} e 
   */
  formSubmit:function(e) {
    var formValue = e.detail.value;
    this.setData({
      searchOptions:true
    })
    var queryParmas = this.data.queryParams;
    queryParmas['minAge'] = formValue.ageMin;
    queryParmas['maxAge'] = formValue.ageMax;
    this.getUsers(queryParmas);
  }
  ,
  /**
   * 侧栏提交
   * @param {*} e 
   */
  formReset:function(e) {
    this.setData({
      searchOptions:true
    })
  },
  /**
   * 详情
   */
  userDetail: function(e) {
    wx.navigateTo({
      url: './detail/index',
      success: function(res) {
        res.eventChannel.emit('customerDetail', {uid:e.currentTarget.dataset.id})
      }
    })
  }
})