import {
  userService
} from "../../common/userService";
import {
  customer,
  imgPreview,
  cacheHistory
} from "../../../providers/constants";
Page({
  data: {
    currentIndex: 0,
    user: {
      previewImg: '',
      imgIds: []
    },
    imgPreviewUrl: imgPreview,
    initImg: false,
    showActionsheet: false,
    groups: [{
        text: '示例菜单',
        value: 1
      },
      {
        text: '示例菜单',
        value: 2
      },
      {
        text: '负向菜单',
        type: 'warn',
        value: 3
      }
    ]
  },
  /**
   * 客户资料编辑
   * 
   * @param {*} e 
   */
  editUser: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../../find/find-add/index',
      success: function (res) {
        res.eventChannel.emit('editUser', {
          uid: that.data.user.id
        })
      }
    })
  },
  /**
   * 页面加载
   */
  onLoad: function () {
    const eventChannel = this.getOpenerEventChannel();
    var that = this;
    eventChannel.on('customerDetail', function (data) {
      userService.loadUser(data.uid).then(res => {
        if (res.success) {
          var user = res.data || {};
          user['previewImg'] = user.imgIds[0] || '';
          if (user.region) {
            user['fullAddress'] = user.region.join("") + (user.address || '') || '';
          }
          var telOptions = [];
          user['phone'] = '';
          if (user.tels) {
            user.tels.forEach(function (value, index, array) {
              telOptions.push({
                text: value,
                value: value
              });

            });

            user['phone'] = user.tels.join(",");
          }
          user['telOptions'] = telOptions;
          that.setData({
            user: user
          })
          // 缓存常用用户
          that.cacheHistory(user);
        }
      })
    })
  },
  // 缓存浏览用户
  cacheHistory(user) {
    var users = [];
    wx.getStorage({
      key: cacheHistory,
      success(res) {
        users = res.data;
        users.forEach(function (item, index, arr) {
          if (item.id == user.id) {
            arr.splice(index, 1);
          }
        });
        users.push(user);
        wx.setStorage({
          data: users,
          key: cacheHistory,
        })
      },
      fail(res) {
        users.push(user);
        wx.setStorage({
          data: users,
          key: cacheHistory,
        })
      }
    })

  },
  /**
   * 图片预览
   * 
   * @param {图片对象} e 
   */
  imgPreview: function (e) {
    var imgIndex = e.currentTarget.dataset.index;
    var imgs = this.data.user.imgIds;
    if (!this.data.initImg) {
      for (let index = 0; index < imgs.length; index++) {
        imgs[index] = this.data.imgPreviewUrl + imgs[index];
      }
      this.setData({
        initImg: true
      })
    }
    wx.previewImage({
      current: imgs[imgIndex],
      urls: imgs
    })
  },
  /**
   * 呼叫电话
   */
  call: function () {
    this.showMutilCall();
  },
  /**
   * 关闭号码选中
   */
  closeMutilCall: function () {
    this.setData({
      showActionsheet: false
    })
  },
  /**
   * 显示号码选中
   */
  showMutilCall: function () {
    this.setData({
      showActionsheet: true
    })
  },
  callSelected: function (e) {
    this.closeMutilCall();
    wx.makePhoneCall({
      phoneNumber: e.detail.value
    })
  }
})